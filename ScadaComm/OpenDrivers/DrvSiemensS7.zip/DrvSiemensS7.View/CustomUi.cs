﻿// Copyright (c) Rapid Software LLC. All rights reserved.
// Licensed under the Apache License, Version 2.0. See License.txt in the project root for license information.

using Scada.Comm.Drivers.DrvSiemensS7.Config;

namespace Scada.Comm.Drivers.DrvSiemensS7.View
{
    /// <summary>
    /// Provides flexibility to the driver user interface.
    /// <para>Обеспечивает гибкость пользовательского интерфейса драйвера.</para>
    /// </summary>
    public class CustomUi
    {
        /// <summary>
        /// Gets a value indicating whether to display the extended options button.
        /// </summary>
        public virtual bool CanShowExtendedOptions => false;


        /// <summary>
        /// Shows the extended template options as a modal dialog box.
        /// </summary>
        /// <returns>Returns true if the options changed.</returns>
        public virtual bool ShowExtendedOptions(DeviceTemplate deviceTemplate) => false;

        /// <summary>
        /// Creates a new device template.
        /// </summary>
        public virtual DeviceTemplate CreateDeviceTemplate() => new();
    }
}
