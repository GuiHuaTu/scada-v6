﻿using S7.Net.Types;
using System;
using System.Collections.Generic;
using System.Text;

namespace Scada.Comm.Drivers.DrvSiemensS7.Config
{
    public class StringClass
    {

        public string StringVariable { get; set; }
    }
}
